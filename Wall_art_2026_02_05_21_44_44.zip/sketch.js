//Wall Drawing 365

function setup() {
  createCanvas(400,400);
}

function draw() {
  background(180);
  
  square(0, 0, 200);
 
  square(200, 0, 0);
  fill(150);
  
  
  square(0, 200, 200);
  fill(100);
 
  square(200, 200, 200);
  fill(200);
 
  
}